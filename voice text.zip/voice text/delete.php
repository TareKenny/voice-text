<?php


require_once 'connect.php';
	$conn->query("DELETE FROM `audio` WHERE `id` = '$_REQUEST[id]'") or die(mysqli_error());
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	