<?php
require_once 'connect.php';


// Set the directory path
$dir = '/Users/cun knee/Downloads';

// Get a list of all M4A audio files in the directory
$files = glob($dir . '/*.m4a');

// Sort the files by modification time (most recent first)
usort($files, function($a, $b) {
    return filemtime($b) - filemtime($a);
});

// Check if there are any M4A audio files
if (!empty($files)) {
    // Get the most recent M4A audio file
    $latest_file = $files[0];

    // Check if the file is an M4A audio file
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $latest_file);
	echo $mime_type ."<br>". $dir ." <br>". $latest_file;
	
    if ($mime_type === 'audio/mp4'){
        echo "<br><br>yeah you did a good job";
    } else{
		echo "<br><br>u dumb";
	}
} else {
    echo "No M4A audio files found in directory";
}








$data_file = new CURLFile($latest_file, 'audio/m4a');
$config = [
    "type" => "transcription",
    "transcription_config" => [
        "operating_point" => "enhanced",
        "language" => "en",
        "enable_entities" => true
    ]
];

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://asr.api.speechmatics.com/v2/jobs/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_HTTPHEADER => array(
    'Authorization: Bearer nTI5cr0H1Ylw3HD660YL260efAAMOIHy'
  ),
  CURLOPT_POSTFIELDS => array(
    'data_file' => $data_file,
    'config' => json_encode($config)
  ),
));

$response = curl_exec($curl);

curl_close($curl);

// Decode the JSON response
$data = json_decode($response, true);

// Get the job ID from the response
$job_id = $data['id'];


$conn->query("INSERT INTO `audio` VALUES('','$latest_file','$job_id')") or die(mysqli_error());

echo "Job ID: $job_id\n";
 
$url = "text dump.php?job_id=" . $job_id;
echo '<a href="' . $url . '" target="_blank"><br><br>Open text dump in new tab</a>';
//header("Location: " . $url);

$read ="read.php";
echo '<a href="' . $read . '" target="_blank"><br><br>Open read in new tab</a>';
exit;