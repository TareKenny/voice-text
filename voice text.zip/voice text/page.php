<?php
require_once 'connect.php';
?>
<html>
<head><title></title>

<script
        src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
        crossorigin="anonymous"></script>
    <script src="voicee.js"></script>   
</head>
<body>

<h1>SPEECH TO TEXT</h1>



<h1>Audio Clip Recorder</h1>

      <p><button id="record">Record</button></p>
	 
	  
	  <a href="appi.php">GO</a>
	  
	  

  
	  <div id="sound-clip"></div>

<BR><BR>
<pre>CONTENT AVAILABLE</pre>
<table border=1 rules="all" width="50%">
						<thead>
						<tr class = "alert-info">
							<th>No.</th>
							<th>File_directory</th>
							<th>Job_id</th>
							<th>Action</th>

						</tr>
						</thead>
						<tbody>
					<?php
						$q_audio = $conn->query("SELECT * FROM `audio`") or die(mysqli_error());
						while($f_audio = $q_audio->fetch_array()){
					?>	
						<tr>
							<td><?php echo $f_audio['id']?></td>
							<td><?php echo $f_audio['directory_fileName']?></td>
							<td><?php echo $f_audio['job_id']?></td>	
							
							
							
							
							<form method="POST" action="delete.php" enctype = "multipart/form-data">
								<input type="hidden" name="id" value="<?php echo $f_audio['id']?>" href="#">
								<td><input type="submit" name="dlt" value="delete"></td>
							</form>
							
							
							</td>
						</tr>
					<?php
					}
				?>
						
						</tbody>
						
						
					</table>


</body>
   

</html>