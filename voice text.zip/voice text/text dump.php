<?php


//$job_id = '5mfefeadhe';

$job_id = $_GET["job_id"];
$format = 'txt';

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://asr.api.speechmatics.com/v2/jobs/$job_id/transcript?format=$format",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Authorization: Bearer nTI5cr0H1Ylw3HD660YL260efAAMOIHy'
  ),
));

$response = curl_exec($curl);

curl_close($curl);



echo "<BR><BR><BR>".$response;

