<?php

$data_file = new CURLFile('/Users/cun knee/Downloads/d.m4a');
$config = [
    "type" => "transcription",
    "transcription_config" => [
        "operating_point" => "enhanced",
        "language" => "en",
        "enable_entities" => true
    ]
];

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://asr.api.speechmatics.com/v2/jobs/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_HTTPHEADER => array(
    'Authorization: Bearer nTI5cr0H1Ylw3HD660YL260efAAMOIHy'
  ),
  CURLOPT_POSTFIELDS => array(
    'data_file' => $data_file,
    'config' => json_encode($config)
  ),
));

$response = curl_exec($curl);

curl_close($curl);

// Decode the JSON response
$data = json_decode($response, true);

// Get the job ID from the response
$job_id = $data['id'];

echo "Job ID: $job_id\n";
 
$url = "text dump.php?job_id=" . $job_id;
header("Location: " . $url);
exit;