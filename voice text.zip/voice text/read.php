<?php
require_once 'connect.php';
?>


<html>
<head><title>READ</title></head>
<body>

<table border=1 rules="all" width="50%">
						<thead>
						<tr class = "alert-info">
							<th>No.</th>
							<th>File_directory</th>
							<th>Job_id</th>
							<th>Action</th>

						</tr>
						</thead>
						<tbody>
					<?php
						$q_audio = $conn->query("SELECT * FROM `audio`") or die(mysqli_error());
						while($f_audio = $q_audio->fetch_array()){
					?>	
						<tr>
							<td><?php echo $f_audio['id']?></td>
							<td><?php echo $f_audio['directory_fileName']?></td>
							<td><?php echo $f_audio['job_id']?></td>	
							
							
							
							
							<form method="POST" action="delete.php" enctype = "multipart/form-data">
								<input type="hidden" name="id" value="<?php echo $f_audio['id']?>" href="#">
								<td><input type="submit" name="dlt" value="delete"></td>
							</form>
							
							
							</td>
						</tr>
					<?php
					}
				?>
						
						</tbody>
						
						
					</table>
					
					
</body>
</html>