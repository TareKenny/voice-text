<?php
	$conn = new mysqli('localhost', 'root', '', 'audio') or die("Database Connection Failed");
	
	